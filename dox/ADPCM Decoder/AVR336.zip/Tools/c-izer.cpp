/*****************************************************************************
*
* Atmel Corporation
*
* File              : c-izer.c
* Compiler          : Dev-Cpp 4.9.9.0 Free Compiler 
*                     (http://www.bloodshed.net/devcpp.html) 
* Revision          : $Revision: 1.2 $
* Date              : $Date: Monday, November 15, 2004 12:26:52 UTC $
* Updated by        : $Author: raapeland $
*
* Support mail      : avr@atmel.com
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : Simple application to convert text output from
*                     the ENCODE tool to a C-array suitable for
*                     direct inclusion. 
*
****************************************************************************/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <exception>

using namespace std;

// Handy typedef for a vector if integers.
typedef vector<int> intVector;



// This function reads the text file created by the
// ENCODE tool and puts all parsed bytes into the data vector.
void read_file( string filename, intVector & data )
{
	ifstream f( filename.c_str() ); // Open a file stream.
	string theText;

	f >> theText; // Pre-read a text element.
	while( !f.eof() ) { // Continue until end of file reached.
		istringstream iss( theText.substr( 2, 2 ) ); // Strip off '0x' and the comma.
		int theByte;
		iss >> hex >> theByte; // Convert hex to integer.
		data.push_back( theByte ); // Fill data vector.
		f >> theText; // Read next text element.
	}
}



// This function writes the contents of the data vector
// to a file formatted as a C-array with some compiler
// specific #pragma directives.
void write_file( string filename, intVector & data )
{
	ofstream f( filename.c_str() ); // Open a file stream.
	f.fill( '0' ); // Now we get e.g. '0x05' instead of '0x 5'.

	// Write a small header.
	f << "/* Array size: " << data.size() << " bytes. */" << endl;
	f << "#pragma memory = __hugeflash" << endl;
	f << "char packed_ [] = {" << endl;

	// Write all bytes in the array.
	for( int i = 0; i < data.size(); i++ ) {
		f << "0x" << hex << setw(2) << data[i];
		if( i != data.size()-1 ) f << ","; // Comma for all but last byte.
		f << " "; // Trailing space.
		if( i % 8 == 7 ) f << endl; // New line after every 8th byte.
	}

	// Write a small footer.
	f << "};" << endl;
	f << "#pragma memory = default" << endl;
	f << "char __hugeflash *packed = packed_;" << endl;
}



int main(int argc, char *argv[])
{
	// Very strict syntax.
	if( argc != 3 ) {
		cerr << "Syntax: c-izer [infile] [outfile]" << endl;
		return -1;
	}

	// Prepare filenames and data vector.
	string infile( argv[1] );
	string outfile( argv[2] );
	intVector theData;

	try {
		read_file( infile, theData ); // Read data into vector.
		write_file( outfile, theData ); // Write out C-array file.
	} catch( exception & e ) {
		cerr << "An exception occured: " << e.what() << endl;
		return -1;
	}

	// Output size information to user.
	cout << "Size: " << theData.size() << " bytes." << endl;
}
