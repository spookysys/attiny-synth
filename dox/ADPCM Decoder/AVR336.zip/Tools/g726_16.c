/*****************************************************************************
*
* Atmel Corporation
*
* File              : g726_16.c
* Compiler          : Microsoft Visual C++ 6.0
* Revision          : $Revision: 1.3 $
* Date              : $Date: Thursday, September 23, 2004 13:21:00 UTC $
* Updated by        : $Author: kmeyer $
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATmega128 / Windows PC (and possibly other platforms
*                     with ANSI-compliant C compiler).
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : 16 kbps routines for the ADPCM Encoder. The encoder
*                     is a supplement to Application Note 336: ADPCM Decoder. 
*                     It is needed to produce encoded data for the decoder. 
*
*                     Portions of software based on code released to 
*                     public domain by Sun Microsystem, Inc.(see notes below).
*
****************************************************************************/

/*
 * This source code is a product of Sun Microsystems, Inc. and is provided
 * for unrestricted use.  Users may copy or modify this source code without
 * charge.
 *
 * SUN SOURCE CODE IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING
 * THE WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 *
 * Sun source code is provided with no support and without any obligation on
 * the part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 *
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY THIS SOFTWARE
 * OR ANY PART THEREOF.
 *
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 *
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */

/*
 * g726_16.c
 *
 * Description:
 *
 * g726_16_encoder(), g726_16_decoder()
 *
 * These routines comprise an implementation of the slightly modified
 * ITU-T G.726 16 Kbps ADPCM coding algorithm.  
 *
 */
#include "g72x.h"

/*
 * Maps G.726_16 code word to reconstructed scale factor normalized log
 * magnitude values.
 */
static short    _dqlntab[4] = {117, 364, 364, 117};

/* Maps G.726_16 code word to log of scale factor multiplier. */
static short	_witab[4] = {-704, 14048, 14048, -704};
/*
 * Maps G.726_16 code words to a set of values whose long and short
 * term averages are computed and then compared to give an indication
 * how stationary (steady state) the signal is.
 */
static short	_fitab[4] = {0, 0xE00, 0xE00, 0};

static short qtab_726_16[1] = {261};


/*
 * g726_16_encoder()
 *
 * Encodes a linear PCM, A-law or u-law input sample and returns 
 * its 2-bit code. Returns -1 if invalid input coding value.
 */
int
g726_16_encoder(
	int		sl,
	int		in_coding,
	struct g72x_state *state_ptr)
{
	short		se, sez;	/* ACCUM */
	short		d;			/* SUBTA */
	short		y;			/* MIX */
	short		sr;			/* ADDB */
	short		dqsez;			/* ADDC */
	short		dq, i;

	switch (in_coding) {	/* linearize input sample to 14-bit PCM */
	case AUDIO_ENCODING_ALAW:
		sl = alaw2linear((unsigned char) sl) >> 2;
		break;
	case AUDIO_ENCODING_ULAW:
		sl = ulaw2linear((unsigned char) sl) >> 2;
		break;
	case AUDIO_ENCODING_LINEAR:
		sl >>= 2;		/* sl of 14-bit dynamic range */
		break;
	default:
		return (-1);
	}

	se = predictor(&sez, state_ptr);

	d = sl - se;			/* d = estimation diff. */

	/* quantize prediction difference d */
	y = step_size(state_ptr);	/* quantizer step size */
	i = quantize(d, y, qtab_726_16, 2);	/* i = ADPCM code */
	dq = reconstruct(i & 2, _dqlntab[i], y); /* quantized diff. */

	sr = se + dq;	/* reconst. signal */

	dqsez = sr + sez - se;		/* pole prediction diff. */

	update(2, y, _witab[i], _fitab[i], dq, sr, dqsez, state_ptr);

	return (i);
}

/*
 * g726_16_decoder()
 *
 * Decodes a 2-bit ADPCM code and returns
 * the resulting 16-bit linear PCM, A-law or u-law sample value.
 * -1 is returned if the output coding is unknown.
 */
int
g726_16_decoder(
	int		i,
	int		out_coding,
	struct g72x_state *state_ptr)
{
	short		sez, se;	/* ACCUM */
	short		y;			/* MIX */
	short		sr;			/* ADDB */
	short		dq;
	short		dqsez;

	i &= 0x07;			/* mask to get proper bits */
	
	se = (short)predictor(&sez, state_ptr);

	y = step_size(state_ptr);	/* adaptive quantizer step size */
	dq = reconstruct(i & 0x02, _dqlntab[i], y); /* unquantize pred diff */

	sr = se + dq;	/* reconst. signal */

	dqsez = sr - se + sez;			/* pole prediction diff. */

	update(2, y, _witab[i], _fitab[i], dq, sr, dqsez, state_ptr);

	switch (out_coding) {
	case AUDIO_ENCODING_ALAW:
		return (tandem_adjust_alaw(sr, se, y, i, 4, qtab_726_16));
	case AUDIO_ENCODING_ULAW:
		return (tandem_adjust_ulaw(sr, se, y, i, 4, qtab_726_16));
	case AUDIO_ENCODING_LINEAR:
		return (sr << 2);	/* sr was of 14-bit dynamic range */
	default:
		return (-1);
	}
}
