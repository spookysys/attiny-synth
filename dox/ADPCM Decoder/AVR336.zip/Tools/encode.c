/*****************************************************************************
*
* Atmel Corporation
*
* File              : encode.c
* Compiler          : Microsoft Visual C++ 6.0
* Revision          : $Revision: 1.3 $
* Date              : $Date: Thursday, September 23, 2004 13:20:52 UTC $
* Updated by        : $Author: kmeyer $
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATmega128 / Windows PC (and possibly other platforms
*                     with ANSI-compliant C compiler).
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : Encoder main loop file, command line parsing and file
*                     i/o routines for the ADPCM Encoder. The encoder is a 
*                     supplement to Application Note 336: ADPCM Decoder. It 
*                     is needed to produce encoded data for the decoder. 
*
*                     Portions of software based on code released to 
*                     public domain by Sun Microsystem, Inc.
*
****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include "g72x.h"


/*
 * Pack output codes into bytes and write them to file f_out.
 * Returns 1 if there is residual output, else returns 0.
 */
int
pack_output(unsigned code, int bits, FILE *f_out)
{
	static unsigned int	out_buffer = 0;
	static int			out_bits = 0;
	unsigned char		out_byte;

	out_buffer |= (code << out_bits);
	out_bits += bits;
	if (out_bits >= 8) {
		out_byte = out_buffer & 0xff;
		out_bits -= 8;
		out_buffer >>= 8;
		fwrite(&out_byte, sizeof (char), 1, f_out);
	}
	return (out_bits > 0);
}

/*
 * Pack output codes into bytes and write them to text file f_out.
 * Returns 1 if there is residual output, else returns 0.
 */
int
pack_output_text(unsigned code, int bits, FILE *f_out)
{
	static unsigned int	out_buffer = 0;
	static int			out_bits = 0;
	static int			col = 0;
	unsigned char		out_byte;

	out_buffer |= (code << out_bits);
	out_bits += bits;
	if (out_bits >= 8) {
		out_byte = out_buffer & 0xff;
		out_bits -= 8;
		out_buffer >>= 8;
		if(col++ >= 7){
			fprintf(f_out, "0x%x,\n", out_byte);
			col = 0;
		} else {
			fprintf(f_out, "0x%x, ", out_byte);
		}
	}
	return (out_bits > 0);
}

/*
 * Prints the usage & parameters etc.
 */

void print_usage(){

	fprintf(stderr, "\nADPCM Encoder -- usage:\n");
	fprintf(stderr, "\tencode [-2|3|4|5] [-a|u|l] -i infile -o|c outfile\n");
	fprintf(stderr, "where:\n");
	fprintf(stderr, "\t-2\tGenerate 16kbps (2-bit) data\n");
	fprintf(stderr, "\t-3\tGenerate 24kbps (3-bit) data\n");
	fprintf(stderr, "\t-4\tGenerate 32kbps (4-bit) data [default]\n");
	fprintf(stderr, "\t-5\tGenerate 40kbps (5-bit) data\n\n");
	fprintf(stderr, "\t-a\tProcess 8-bit A-law input data\n");
	fprintf(stderr, "\t-u\tProcess 8-bit u-law input data [default]\n");
	fprintf(stderr, "\t-l\tProcess 16-bit linear PCM input data\n\n");
	fprintf(stderr, "\t-i\tInput file (binary)\n\n");
	fprintf(stderr, "\t-o\tOutput file (binary)\n");
	fprintf(stderr, "\t-c\tOutput file (text file ready to be pasted into c-array)\n");
}


main(
	int			argc,
	char			**argv)
{
	struct g72x_state	state;
	unsigned char		sample_char;
	short			sample_short;
	unsigned char		code;
	int			resid;
	int			in_coding;
	int			in_size;
	unsigned		*in_buf;
	int			(*enc_routine)();
	int			enc_bits;
	
	
	char *infile;
	char *outfile;

	int c_output = 0;

	FILE *f_in = NULL;
	FILE *f_out = NULL;

	g72x_init_state(&state);

	/* Set defaults to linear input, 32 kbps output */
	in_coding = AUDIO_ENCODING_LINEAR;
	in_size = sizeof (char);
	in_buf = (unsigned *)&sample_char;
	enc_routine = g726_32_encoder;
	enc_bits = 4;

	

	argc--;
	argv++;
	/* Process encoding argument, if any */
	while ((argc > 0) && (argv[0][0] == '-')) {
		switch (argv[0][1]) {
		case '2':
			enc_routine = g726_16_encoder;
			enc_bits = 2;
			break;
		case '3':
			enc_routine = g726_24_encoder;
			enc_bits = 3;
			break;
		case '4':
			enc_routine = g726_32_encoder;
			enc_bits = 4;
			break;
		case '5':
			enc_routine = g726_40_encoder;
			enc_bits = 5;
			break;
		case 'u':
			in_coding = AUDIO_ENCODING_ULAW;
			in_size = sizeof (char);
			in_buf = (unsigned *)&sample_char;
			break;
		case 'a':
			in_coding = AUDIO_ENCODING_ALAW;
			in_size = sizeof (char);
			in_buf = (unsigned *)&sample_char;
			break;
		case 'l':
			in_coding = AUDIO_ENCODING_LINEAR;
			in_size = sizeof (short);
			in_buf = (unsigned *)&sample_short;
			break;
		case 'i':
			infile = &argv[0][2];
			if (*infile == NULL){
				argv++;
				argc--;
				infile = &argv[0][0];
			}
			f_in = fopen(infile, "rb");
			if (f_in == NULL){
				fprintf(stderr, "\nCan't open input file %s.\n", infile);
				exit(1);
			}
			break;
		case 'o':
			outfile = &argv[0][2];
			if (*outfile == NULL){
				argv++;
				argc--;
				outfile = &argv[0][0];
			}
			f_out = fopen(outfile, "wb");
			if (f_out == NULL){
				fprintf(stderr, "\nCan't open output file %s.\n", outfile);
				exit(1);
			}
			break;
		case 'c':
			c_output = 1;
			outfile = &argv[0][2];
			if (*outfile == NULL){
				argv++;
				argc--;
				outfile = &argv[0][0];
			}
			f_out = fopen(outfile, "wt");
			if (f_out == NULL){
				fprintf(stderr, "\nCan't open output file %s.\n", outfile);
				exit(1);
			}
			break;


		default:
			print_usage();
			exit(1);
		}
		argc--;
		argv++;
	}

	if ((f_out == NULL) || (f_in == NULL)){
		print_usage();
		exit(1);
	}

	/* Read input file and process */
	while (fread(in_buf, in_size, 1, f_in) == 1) {
		
		code = (*enc_routine)(in_size == 2 ? sample_short : sample_char,
		    in_coding, &state);
		if(c_output)
			resid = pack_output_text(code, enc_bits, f_out);
		else
			resid = pack_output(code, enc_bits, f_out);
	}

	
	/* Write zero codes until all residual codes are written out */
	while (resid) {
		if(c_output)
			resid = pack_output_text(code, enc_bits, f_out);
		else
			resid = pack_output(0, enc_bits, f_out);
	}

	fclose(f_out);
	fclose(f_in);

}
