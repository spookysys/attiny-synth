/*****************************************************************************
*
* Atmel Corporation
*
* File              : decode.c
* Compiler          : Microsoft Visual C++ 6.0
* Revision          : $Revision: 1.3 $
* Date              : $Date: Thursday, September 23, 2004 13:20:48 UTC $
* Updated by        : $Author: kmeyer $
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATmega128 / Windows PC (and possibly other platforms
*                     with ANSI-compliant C compiler).
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : Decoder main loop file, command line parsing and file
*                     i/o routines. 
*
*                     Portions of software based on code released to 
*                     public domain by Sun Microsystem, Inc.
*
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "g72x.h"


/*
 * Prints the usage & parameters etc.
 */

void print_usage(){

	fprintf(stderr, "\nADPCM Decoder -- usage:\n");
	fprintf(stderr, "\tdecode [-2|3|4|5] [-a|u|l] -i infile -o outfile\n");
	fprintf(stderr, "where:\n");

	fprintf(stderr, "\t-3\tProcess 24kbps (3-bit) input data\n");
	fprintf(stderr, "\t-4\tProcess 32kbps (4-bit) input data [default]\n");
	fprintf(stderr, "\t-5\tProcess 40kbps (5-bit) input data\n\n");
	
	fprintf(stderr, "\t-a\tGenerate 8-bit A-law data\n");
	fprintf(stderr, "\t-u\tGenerate 8-bit u-law data\n");
	fprintf(stderr, "\t-l\tGenerate 16-bit linear PCM data [default]\n\n");

	fprintf(stderr, "\t-i\tInput file (binary)\n\n");
	fprintf(stderr, "\t-o\tOutput file (binary)\n");
	
}


/*
 * Unpack input codes and pass them back as bytes.
 * Returns 1 if there is residual input, returns -1 if eof, else returns 0.
 */
int
unpack_input(
	unsigned char		*code,
	int			bits,
	FILE *fin)
{
	static unsigned int	in_buffer = 0;
	static int		in_bits = 0;
	unsigned char		in_byte;

	if (in_bits < bits) {
		if (fread(&in_byte, sizeof (char), 1, fin) != 1) {
			*code = 0;
			return (-1);
		}
		in_buffer |= (in_byte << in_bits);
		in_bits += 8;
	}
	*code = in_buffer & ((1 << bits) - 1);
	in_buffer >>= bits;
	in_bits -= bits;
	return (in_bits > 0);
}


main(
	int			argc,
	char			**argv)
{
	short			sample;
	unsigned char		code;
	struct g72x_state	state;
	int			out_coding;
	int			out_size;
	int			(*dec_routine)();
	int			dec_bits;

	FILE *f_in = NULL;
	FILE *f_out = NULL;
	char *infile;
	char *outfile;
	

	g72x_init_state(&state);
	out_coding = AUDIO_ENCODING_ULAW;
	out_size = sizeof (char);
	dec_routine = g726_32_decoder;
	dec_bits = 4;


	/* Process encoding argument, if any */
	argc--;
	argv++;
	while ((argc > 0) && (argv[0][0] == '-')) {
		switch (argv[0][1]) {
		case '2':
			dec_routine = g726_16_decoder;
			dec_bits = 2;
			break;
		case '3':
			dec_routine = g726_24_decoder;
			dec_bits = 3;
			break;
		case '4':
			dec_routine = g726_32_decoder;
			dec_bits = 4;
			break;
		case '5':
			dec_routine = g726_40_decoder;
			dec_bits = 5;
			break;
		case 'u':
			out_coding = AUDIO_ENCODING_ULAW;
			out_size = sizeof (char);
			break;
		case 'a':
			out_coding = AUDIO_ENCODING_ALAW;
			out_size = sizeof (char);
			break;
		case 'l':
			out_coding = AUDIO_ENCODING_LINEAR;
			out_size = sizeof (short);
			break;
		case 'i':
			infile = &argv[0][2];
			if (*infile == NULL){
				argv++;
				argc--;
				infile = &argv[0][0];
			}
			f_in = fopen(infile, "rb");
			if (f_in == NULL){
				printf("cant open %s", infile);
				exit(1);
			}
			break;
		case 'o':
			outfile = &argv[0][2];
			if (*outfile == NULL){
				argv++;
				argc--;
				outfile = &argv[0][0];
			}
			f_out = fopen(outfile, "wb");
			if (f_out == NULL){
				printf("cant open %s", outfile);
				exit(1);
			}
			break;

		default:
			print_usage();
			exit(1);
		}
		argc--;
		argv++;
	}

	if ((f_out == NULL) || (f_in == NULL)){
		print_usage();
		exit(1);
	}

	/* Read and unpack input codes and process them */
	while (unpack_input(&code, dec_bits, f_in) >= 0) {
		sample = (*dec_routine)(code, out_coding, &state);
		if (out_size == 2) {
			fwrite(&sample, out_size, 1, f_out);
		} else {
			code = (unsigned char)sample;
			fwrite(&code, out_size, 1, f_out);
		}
	}
	fclose(f_out);
	fclose(f_in);
}
