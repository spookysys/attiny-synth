/*****************************************************************************
*
* Atmel Corporation
*
* File              : adpcm.h
* Compiler          : IAR EWAAVR 3.10C
* Revision          : $Revision: 1.4 $
* Date              : $Date: Monday, November 15, 2004 12:53:58 UTC $
* Updated by        : $Author: raapeland $
*
* Support mail      : avr@atmel.com
*
* Supported devices : This example is written for the ATmega128. The firmware
*                     should compile on any AVR with at least 4kB of Flash
*                     memory (plus enough room for sound data).
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : ADPCM Decoder header file, state structure definition 
*                     and function prototypes, bit level definitions etc. 
*
****************************************************************************/


#include "ioavr.h"

/*
 * ADPCM state structure
 */
 
typedef struct adpcm_state_ {
	long yl;	// Locked (slow) state scale factor step size mult.
	short yu;	// Unlocked (fast) state scale factor step size mult.
	short dms;	// Short term energy estimate.
	short dml;	// Long term energy estimate.
	short ap;	// Linear weighting coefficient of 'yl' and 'yu'.

	short a[2];	// Coefficients of pole portion of prediction filter.
	short b[6];	// Coefficients of zero portion of prediction filter.
	short pk[2];	// Signs of previous partially reconstructed signals.

	short dq[6];	// Previous samples of the quantized difference signal.
	short sr[2];	// Previous samples of the reconstructed signal .
	char td;	// Tone detection indicator.
} *adpcm_state;

/*
 * Function prototypes.
 */

int scale_factor_adapt(adpcm_state state);
extern long update_yl(long yl, int yu); 
int decode(char i, adpcm_state state);
short predictor(short *sez, adpcm_state state);
void adaptation_speed_control(int fi, int tr, int y, adpcm_state state);
char transition_detection(short dql, adpcm_state state);
int antilog(int sign, int dql);
short update_pred_coeff(int	dq,
	                int	sr,
	                int	dqsez,
                        char    tr,
                        char    pk0,
                        adpcm_state state);
void initialize_adpcm(adpcm_state state);
unsigned char get_code(void);
void initialize_pwm(void);


#pragma vector = TIMER3_COMPA_vect
__interrupt void TIMER3_COMPA(void);


/*
 * Definitions (bit level, PWM mode etc.) 
 */


#define INPUTSIZE 58335   // size of sound record
#define END_OF_DATA 100     // returned by get_code() when no data left
#define BITS 5              // bit level (2, 3, 4 or 5)
#define BUFFER_SIZE 128     // output buffer size (max. 255 due to index
                            // variables being of type 'char')
