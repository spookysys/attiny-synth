/*****************************************************************************
*
* Atmel Corporation
*
* File              : main.c
* Compiler          : IAR EWAAVR 3.10C
* Revision          : $Revision: 1.4 $
* Date              : $Date: Monday, November 15, 2004 12:53:58 UTC $
* Updated by        : $Author: raapeland $
*
* Support mail      : avr@atmel.com
*
* Supported devices : This example is written for the ATmega128. The firmware
*                     compiles on any AVR with at least 4kB of Flash (plus
*                     enough room for sound data). It is recommended to use
*                     AVRs with hardware multiplier.
*
* AppNote           : AVR336: ADPCM Decoder.
*
* Description       : ADPCM Decoder main program. By IV & KMe.
*
****************************************************************************/

#include<stdio.h>
#include<stdlib.h>

#include"adpcm.h"
#include"ioavr.h"
#include"inavr.h"


// function definitions: 

extern int decode(char i, adpcm_state state);
extern unsigned char get_code(void);
void main(void);


// global variables:

extern char   __hugeflash *packed;  // pointer to ADPCM-packed sound record
signed int    sample = 0;           // decoded sample

int               buffer[BUFFER_SIZE];  // output buffer 
unsigned char     decoder_ind = 0;      // decoder index to buffer
unsigned char     da_ind = 0;           // dac index to buffer


void main(){

  unsigned char code = 0;
  int sample;
  struct adpcm_state_ init_state;
  adpcm_state state = &init_state;

  DDRB |= 4;
  DDRB |= 1;
  PORTB |= 4;

  initialize_pwm();     
  
  while(1){
    initialize_adpcm(state);
    code = 0;
    PORTD = 0xFF;         // enable internal pull-ups on port D
    while(PIND == 0xFF);  // wait for keypress

    // fill output buffer:
    for (decoder_ind = 0; decoder_ind < BUFFER_SIZE; decoder_ind++){  
      code = get_code();
      if (code == END_OF_DATA)
        break;
      sample = decode(code, state);
      buffer[decoder_ind] = sample >> 5;
    }
    decoder_ind = 0;
    da_ind = 0;

    __enable_interrupt();
    while (code != END_OF_DATA){
      PORTB &= 0xFE;        // toggle PB0: use oscilloscope to monitor duty
      code = get_code();       
      if (code != END_OF_DATA){         // end of recording?
        sample = decode(code, state);   // decode one sample
        if(abs(sample >> 5) > 255)      // make sure that 
          sample = 0;                    
        PORTB |= 1;         // toggle PB0
        while(decoder_ind == da_ind);  // wait for empty space in buffer

        // 9-bit pwm, decode returns 14-bit value -> shift by 5
        buffer[decoder_ind] = sample >> 5;
        __disable_interrupt();
        decoder_ind++;
        __enable_interrupt();
        if(decoder_ind>=BUFFER_SIZE)
          decoder_ind = 0;
      }
    }
    __disable_interrupt();
  }
}
