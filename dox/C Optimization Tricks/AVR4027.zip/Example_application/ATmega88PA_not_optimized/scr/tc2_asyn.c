/**
* \file *********************************************************************
*
* \brief  None optimized example application: timer/counter2 source code.
*
*      This file contains the TC2 module initialization function.
*
* \par Application note:
*      AVR4027: Tips and tricks to optimize your C-code for 8-bit AVR
*
* \author
*      Atmel Corporation: http://www.atmel.com \n
*      Support email: avr@atmel.com
*
* $Revision$
* $Date$  \n
*
* Copyright (C) 2011 Atmel Corporation. All rights reserved.
*
* \page License
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* 3. The name of Atmel may not be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* 4. This software may only be redistributed and used in connection with an
* Atmel AVR product.
*
* THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
* EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*****************************************************************************/

#include "tc2_asyn.h"

void tc2_power_on(void)
{
	PRR &= ~( 1<<PRTIM2 );
}

void tc2_asyn_init(void)
{
	tc2_power_on();
	ASSR = ( 1<<EXCLK );                  // select external clock
	ASSR |= ( 1<<AS2 );                   // enable asynchronous mode
	
	TCNT2 = 0;
	while( ASSR & ( 1<<TCN2UB ));
	
	OCR2A = 0x00;
	while( ASSR & ( 1<<OCR2AUB ));
	OCR2B = 0x00;
	while( ASSR & ( 1<<OCR2BUB ));
	
	TCCR2A = 0x00;
	while( ASSR & ( 1<<TCR2AUB ));
	TCCR2B = ( 1<<CS22 | 1<<CS20 );       // 1/128 prescaler @ 32768hz outputs 1 second RTC
	while( ASSR & ( 1<<TCR2BUB ));
	
	TIFR2 = 0x00;
	TIMSK2 = ( 1<<TOIE2 );               // enable timer2 overflow interrupt
}

