/**
* \file *********************************************************************
*
* \brief  None optimized example application: main.c
*
*      In the example, one ADC channel is used to sample the input and the 
*      result is sent out through USART every five second. If the ADC result is
*      out of range, alarm is sent out for 30 seconds before the application is
*      locked in error state. In the rest of the main loop, the device is put 
*      in power save mode.
*
* \par Application note:
*      AVR4027: Tips and tricks to optimize your C-code for 8-bit AVR
*
* \par Compiler          : AVR GCC 8-bit toolchain
* \par Revision          : gcc version 4.5.1
* 
* \author
*      Atmel Corporation: http://www.atmel.com \n
*      Support email: avr@atmel.com
*
* $Revision$
* $Date$  \n
*
* Copyright (C) 2011 Atmel Corporation. All rights reserved.
*
* \page License
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* 3. The name of Atmel may not be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* 4. This software may only be redistributed and used in connection with an
* Atmel AVR product.
*
* THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
* EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*****************************************************************************/

#include "adc.h"
#include "usart.h"
#include "tc2_asyn.h"
#include "ADC_to_USART.h"
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>

char error[] = {" ERROR"};
char hot[] = {" HOT"};
char cool[] = {" COOL"};
uint8_t adc_cnt = 0;
uint8_t adc_sum[ADC_NUM]= {0};
uint8_t cycle_cnt = 0;
	
int main()
{
	// Shut down unused module to save power.
	power_reduce();
	// IO port initialization.
	io_init();
	// Enable and initialize ADC module.
	adc_init();
	// USART initialization.
	usart_init();
	// Timer2 initialized in asynchronous mode.
	tc2_asyn_init();
	// Enable global interrupt.
	sei();
	
	while(1) {
		// Sleep CPU until timer2 overflow interrupt wakes it up.
		set_sleep_mode (SLEEP_MODE_PWR_SAVE);
		sleep_mode();
		/* toggle pin to indicate loop start */
		PIND |= 1<<PIND0;
		
		if ( cycle_cnt > ALARM_N){
			USART0_Transmit_String(error);
		} else {
			// Get ADC result and decide current status.
			uint8_t temp = adc_to_buffer();
			if (temp > ADC_TOP){
				USART0_Transmit_String(hot);
				cycle_cnt++;
			} else if (temp < ADC_BOT){
				USART0_Transmit_String(cool);
				cycle_cnt++;
			} else {
				adc_sum[adc_cnt++] = temp;
				cycle_cnt = 0;
			}
		}
		// Get filtered ADC result and send it out through USART.
		if (adc_cnt >= ADC_NUM) {
			adc_cnt = 0;
			USART0_Transmit( adc_filter_mid(adc_sum, ADC_NUM) );
		}
		/* toggle pin to indicate loop end */
		PIND |= 1<<PIND0;
	}
}

/* ADC result filtered by using middle value */
uint8_t adc_filter_mid(uint8_t *buffer, uint8_t buffer_cnt)
{
	for (uint8_t i = 0; i < buffer_cnt ; i++) {
		for (uint8_t j = 0; j < buffer_cnt ; j++) {
			if (buffer[j] < buffer[j+1]) {
				uint8_t temp;
				temp = buffer[j+1];
				buffer[j+1] = buffer[j];
				buffer[j] = temp;
			}
		}
	}
	return buffer[buffer_cnt>>1];
}

/* TC2 overflow interrupt */
ISR (TIMER2_OVF_vect)
{
	TIFR2 |= 1<<TOV2;
}



