/** 
* \file *********************************************************************
*
* \brief  Optimized example application: ADC source code.
*
*      This file contains the function prototypes and definitions of ADC module
*
* \par Application note:
*      AVR4027: Tips and tricks to optimize your C-code for 8-bit AVR
*
* \author
*      Atmel Corporation: http://www.atmel.com \n
*      Support email: avr@atmel.com
*
* $Revision$
* $Date$  \n
*
* Copyright (C) 2011 Atmel Corporation. All rights reserved.
*
* \page License
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* 3. The name of Atmel may not be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* 4. This software may only be redistributed and used in connection with an
* Atmel AVR product.
*
* THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
* EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*****************************************************************************/

#include "adc.h"

void adc_init(void)
{
	adc_power_on();
	ADMUX = ( 1<<REFS1 | 1<<REFS0 | 1<<MUX3 );           // select internal temp sensor
	//ADMUX = ( 1<<REFS0 | 1<<MUX1 );                      // AVcc reference and ADC2 selected
	ADCSRA = ( 1<<ADEN | 1<<ADPS1 | 1<<ADPS0 );          // ADC enable, single conversion mode, 1/8 prescaler
	DIDR0 = ( 1<<ADC0D | 1<<ADC1D | 1<<ADC2D | 1<<ADC3D | 1<<ADC4D | 1<<ADC5D );
}

uint8_t adc_to_buffer(void)
{
	while ( ADCSRA & ( 1<<ADSC ));
	adc_start();
	while ( !( ADCSRA & ( 1<<ADIF )));
	ADCSRA |= ( 1<<ADIF );
	//return (((ADCL<<8)|ADCH)-Tos)/K_coefficient;
	return (uint8_t)(((ADCL|(ADCH<<8))-Tos)>>K_coefficient);
}
