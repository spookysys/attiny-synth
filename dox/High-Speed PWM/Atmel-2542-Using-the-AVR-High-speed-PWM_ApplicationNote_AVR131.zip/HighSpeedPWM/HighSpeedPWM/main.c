/**
 * \file
 *
 * \brief High Speed PWM.
 *
 * Copyright (c) 2015 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * main.c file
 *
 * Project demonstrate High-Speed PWM of Tiny26 device and thus generate
 * a sine wave by passing the PWM output through a RC Low Pass filter.
 *
 *
 */
 
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/sleep.h>


volatile unsigned char sine_table_pointer = 0;
const unsigned char sine_table[] PROGMEM;

void init(void)
{
	// enable and lock PLL
	PLLCSR = (1<<PLLE);

	while((PLLCSR & (1<<PLOCK)) == 0);
		
	// set PLL as PWM clock source
	PLLCSR |= (1<<PCKE);

	// set PWM mode: set OC1A on compare
	TCCR1A = ((1<<PWM1A) | (1<<COM1A0));
	
	// set falling edge (top) value
	OCR1C = 0xFF;

	// set the clock pre-scaler bits
	TCCR1B = ((1<<CS10) | (1<<CS11) | (1<<CTC1));

	// Enable interrupt
	TIMSK |= (1<<OCIE1A);
	
	// set OC1A to output
	DDRB |= (1<<PB1);
	
}

int main(void)
{
	//Initialize the system
	init();
	
	//global interrupt enable
	sei();	

	// Enable sleep mode
	sleep_enable();

	while(1){	
		//Enter Sleep mode
		sleep_cpu();
	}	
}

//Timer/Counter1 ISR
ISR(TIMER1_CMPA_vect)
{
	OCR1A = pgm_read_byte(&sine_table[sine_table_pointer++]);
}

//Sine Wave Look Up Table 
const unsigned char sine_table[] PROGMEM =
{
	128, 131, 134, 137, 140, 144, 147, 150, 153, 156, 159, 162, 165, 168, 171, 174, 
	177, 179, 182, 185, 188, 191, 193, 196, 199, 201, 204, 206, 209, 211, 213, 216, 
	218, 220, 222, 224, 226, 228, 230, 232, 234, 235, 237, 238, 240, 241, 243, 244, 
	245, 246, 248, 249, 250, 250, 251, 252, 253, 253, 254, 254, 254, 255, 255, 255, 
	255, 255, 255, 255, 254, 254, 254, 253, 253, 252, 251, 250, 250, 249, 248, 247, 
	245, 244, 243, 241, 240, 239, 237, 235, 234, 232, 230, 228, 226, 224, 222, 220, 
	218, 216, 213, 211, 209, 206, 204, 201, 199, 196, 193, 191, 188, 185, 182, 180, 
	177, 174, 171, 168, 165, 162, 159, 156, 153, 150, 147, 144, 141, 138, 134, 131, 
	128, 125, 122, 119, 116, 113, 110, 106, 103, 100, 97, 94, 91, 88, 85, 83, 
	80, 77, 74, 71, 68, 66, 63, 60, 58, 55, 53, 50, 48, 45, 43, 41, 
	38, 36, 34, 32, 30, 28, 26, 24, 23, 21, 19, 18, 16, 15, 13, 12, 
	11, 10, 9, 7, 7, 6, 5, 4, 3, 3, 2, 2, 2, 1, 1, 1, 
	1, 1, 1, 1, 2, 2, 2, 3, 3, 4, 5, 6, 6, 7, 8, 9, 
	11, 12, 13, 14, 16, 17, 19, 21, 22, 24, 26, 28, 30, 32, 34, 36, 
	38, 40, 42, 45, 47, 50, 52, 55, 57, 60, 62, 65, 68, 71, 73, 76, 
	79, 82, 85, 88, 91, 94, 97, 100, 103, 106, 109, 112, 115, 118, 121, 124
};